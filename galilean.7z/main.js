var reader = new FileReader();
var xlsflag = true;
reader.onload = function (e) {
    var data = e.target.result;
    /*Converts the excel data in to object*/
    if (xlsxflag) {
        var workbook = XLSX.read(data, { type: 'binary' });
    }
    else {
        var workbook = XLS.read(data, { type: 'binary' });
    }
    /*Gets all the sheetnames of excel in to a variable*/
    var sheet_name_list = workbook.SheetNames;
    var data = {};
    sheet_name_list.forEach(function (y) { /*Iterate through all sheets*/
        /*Convert the cell value to Json*/
        if (xlsxflag) {
            var exceljson = XLSX.utils.sheet_to_json(workbook.Sheets[y]);
        }
        else {
            var exceljson = XLS.utils.sheet_to_row_object_array(workbook.Sheets[y]);
        }
        if (exceljson.length > 0) {
            data[y] = exceljson;
        }
            // var display = document.getElementById(y);
            // var display = $('#Monday')[0];
            // display.innerText=JSON.stringify(exceljson);
            // $(display).show();
        // }
    });
    var days = ['Sunday','Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    var display = $('#display');
    display.show();
    display = display[0];
    var todate = new Date();
    $('#date')[0].innerHTML = 'The time now is: ' + todate.toString();
    var today = todate.getDay();
    day = days[today];
    var hour = todate.getHours();
    // for (i in days) {
    //     var day = days[i];
    var msg = '<span>Schedules for ' + ('0'+hour).slice(-2) + ':00 - ' +
        ('0'+(hour+1)).slice(-2) + ':00:</span><br>';
    var schedule = data[day];
    if (schedule) {
        schedule = schedule.filter(function (e) {
            return e.hour === hour.toString();
        });
        if (schedule) schedule = schedule[0];
    }
    var busy = false;
    if (!schedule) {
        msg += '<br>No Activity';
    } else {
        var names = [];
        for (r = 1; r < 10; r++) {
            if (schedule[r] && schedule[r].trim()) {
                names.push({
                    name: schedule[r],
                    room: r,
                });
            }
        }
        names.forEach(function (e) {
            busy = true;
            msg += '<br><span>Room ' + e.room + ': ' +
                details(e.name, data.names);
        })
        if (!busy) msg += '<span>All Free';
    }
    msg += '</span>';
    if (!display.innerHTML) display.innerHTML = '';
    display.innerHTML += msg;
    // alert(day);
}

function details(name, namesData) {
    drow = namesData.filter(function(d) {
        return d.id === name;
    });
    if (drow) {
        drow = drow[0];
        var result = drow.name + ':' + drow.field;
        if (drow.picture) result += '<img src="' + drow.picture +
            '" width="50" height="50" alt="' + name + '"></img>';
        return result;
    } else
        return '<span>' + name;
}
function ExportToTable() {
    var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.xlsx|.xls)$/;
    /*Checks whether the file is a valid excel file*/

    if (regex.test($("#excelfile").val().toLowerCase())) {
        xlsxflag = false; /*Flag for checking whether excel is .xls format or .xlsx format*/
        if ($("#excelfile").val().toLowerCase().indexOf(".xlsx") > 0) {
            xlsxflag = true;
        }
        /*Checks whether the browser supports HTML5*/
        if (typeof (FileReader) != "undefined") {
           if (xlsxflag) {/*If excel file is .xlsx extension than creates a Array Buffer from excel*/
                reader.readAsArrayBuffer($("#excelfile")[0].files[0]);
            }
            else {
                reader.readAsBinaryString($("#excelfile")[0].files[0]);
            }
        }
        else {
            alert("Sorry! Your browser does not support HTML5!");
        }
    }
    else {
        alert("Please upload a valid Excel file!");
    }
}
function BindTable(jsondata, tableid) {/*Function used to convert the JSON array to Html Table*/
    var columns = BindTableHeader(jsondata, tableid); /*Gets all the column headings of Excel*/
    for (var i = 0; i < jsondata.length; i++) {
        var row$ = $('<tr/>');
        for (var colIndex = 0; colIndex < columns.length; colIndex++) {
            var cellValue = jsondata[i][columns[colIndex]];
            if (cellValue == null)
                cellValue = "";
            row$.append($('<td/>').html(cellValue));
        }
        $(tableid).append(row$);
    }
}
function BindTableHeader(jsondata, tableid) {/*Function used to get all column names from JSON and bind the html table header*/
    var columnSet = [];
    var headerTr$ = $('<tr/>');
    for (var i = 0; i < jsondata.length; i++) {
        var rowHash = jsondata[i];
        for (var key in rowHash) {
            if (rowHash.hasOwnProperty(key)) {
                if ($.inArray(key, columnSet) == -1) {/*Adding each unique column names to a variable array*/
                    columnSet.push(key);
                    headerTr$.append($('<th/>').html(key));
                }
            }
        }
    }
    $(tableid).append(headerTr$);
    return columnSet;
}
